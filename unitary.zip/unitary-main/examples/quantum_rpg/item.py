# Copyright 2023 The Unitary Authors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import re
from typing import Any, Callable, Optional, Sequence, Tuple, Union

from . import game_state

# Common synonyms for action keywords for different objects:
EXAMINE = ["read", "look", "examine", "investigate", "search"]
TALK = ["talk", "chat", "ask"]

# Note: second argument is a World, omitting to avoid circular dependency
ITEM_FUNCTION_TYPE = Callable[[game_state.GameState, Any], Optional[str]]
ITEM_ACTION_TYPE = Union[str, ITEM_FUNCTION_TYPE]


class Item:
    """An item is an object or person that can be interacted with.

    items have keywords that you can associate with them to
    interact with them, such as 'talk' for people, or press for
    button.

    Future functionality may allow these items to be picked up
    as well.

    Attributes:
        keyword_actions: Tuples of keywords and targets to actions.  A keyword
           is a single verb that can be used to interact with the item.
           An action is a string that is printed out, or a callable
           that will perform some sort of action.
        keyword_targets:  Optional list of targets.  For instance,
           ['Erwin', 'physicist'] would match 'talk Erwin' or
           'talk physicist'. If this is blank, the item will
           intercept all commands with the keyword_actions.
        description: Optional string that will be printed out as
           part of the room description.
    """

    def __init__(
        self,
        keyword_actions: Sequence[
            Tuple[
                Union[str, Sequence[str]],
                Optional[Union[str, Sequence[str]]],
                ITEM_ACTION_TYPE,
            ]
        ],
        description: Optional[str] = None,
    ):
        self.keyword_actions = keyword_actions
        self.description = description

    def get_action(self, user_input: str) -> Optional[ITEM_ACTION_TYPE]:
        words = user_input.lower().split()
        if not words:
            return None
        keyword = words[0]
        user_target = words[1] if len(words) > 1 else None
        for keywords, targets, action in self.keyword_actions:
            target_list = [targets] if not isinstance(targets, list) else targets
            if keyword == keywords or keyword in keywords:
                if not target_list:
                    # All targets valid
                    return action
                if not user_target:
                    # No target specified
                    return f"{keyword} what?"
                for target in target_list:
                    if isinstance(target, re.Pattern):
                        # REgex
                        if user_target and re.match(target, user_target):
                            return action
                    else:
                        # String
                        if user_target == target:
                            return action
        return None
